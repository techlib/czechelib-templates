`mango-cli` project [http://mangocli.org]
===========================

Do you have `mango-cli` installed globally?

If not: `npm install -g mango-cli`

Development
-----------------
Go to that directory. Install project's dependencies `mango install`.

Oh, that's it? Run `mango dev` and your browser should start up.
